﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030481921022
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double vendaMes1 = 0;
            double vendaMes2 = 0;
            string retorno = "";
            

            double[,] vendas = new double[2, 4];
            for(int i = 0; i < 2; i++)
            {
                for (int sem = 0; sem< 4; sem ++)
                {
                    retorno = Interaction.InputBox("Semana: " + (sem+1).ToString(), "Digite os dados do Mes" + (i+1).ToString());
                    double.TryParse(retorno,out vendas[i, sem]);
                }
                if(i == 0)
                {
                    listBox.Items.Add("Calculo do Mes 1 \n");
                    for (int cont = 0; cont < 4; cont++)
                    {
                        vendaMes1 = vendaMes1 + vendas[0, cont];
                       listBox.Items.Add("Semana: " + (cont+1).ToString() + " | Venda" + vendas[0, cont].ToString("N2")); 
                    }
                    listBox.Items.Add(">>>>> Total Mes: " + vendaMes1.ToString("N2"));
                }else if (i == 1)
                {
                    listBox.Items.Add("\nCalculo do Mes 2 \n");
                    for (int cont = 0; cont < 4; cont++)
                    {
                        vendaMes2 = vendaMes2 + vendas[1, cont];
                        listBox.Items.Add("Semana: " + (cont+1).ToString() + " | Venda" + vendas[1, cont].ToString("N2"));
                    }
                    listBox.Items.Add(">>>>> Total Mes: " + vendaMes2.ToString("N2"));
                }
            }
            listBox.Items.Add(">>>>>> Total Geral: " + (vendaMes1 + vendaMes2).ToString("N2"));
        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}
